import axios from 'axios'
const AI_URL=process.env.AI_SERVICE_URL||'http://localhost:5001'
export async function analyzeImage(_buffer,fields){const {data}=await axios.post(`${AI_URL}/analyze`,{assumed_type:fields.assumed_type||null});return data}
export async function rankWithAI(quotes){try{const {data}=await axios.post(`${AI_URL}/rank`,{quotes});return data.items}catch(e){return quotes.map(x=>({...x,total_price:(x.price||0)+(x.delivery_fee||0)+(x.tax||0)})).sort((a,b)=>a.total_price-b.total_price)}}
