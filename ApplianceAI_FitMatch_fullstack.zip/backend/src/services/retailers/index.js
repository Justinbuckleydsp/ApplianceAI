import {queryMock} from './provider_mock.js'
import {queryBestBuy} from './provider_bestbuy.js'
import {queryHomeDepot} from './provider_homedepot.js'
import {queryLowes} from './provider_lowes.js'
export async function fetchRetailerQuotes({type,width_in,height_in,depth_in,query}){const tasks=[queryBestBuy({type,width_in,height_in,depth_in,query}),queryHomeDepot({type,width_in,height_in,depth_in,query}),queryLowes({type,width_in,height_in,depth_in,query}),queryMock({type,width_in,height_in,depth_in,query})];const results=await Promise.allSettled(tasks);return results.filter(r=>r.status==='fulfilled').flatMap(r=>r.value)}
