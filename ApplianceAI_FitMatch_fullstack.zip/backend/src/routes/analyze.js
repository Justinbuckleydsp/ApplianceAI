import express from 'express'
import formidable from 'formidable'
import {analyzeImage} from '../services/ai_client.js'
const router=express.Router()
router.post('/',async(req,res)=>{const form=formidable({multiples:false});form.parse(req,async(err,fields,files)=>{if(err)return res.status(400).json({error:'Invalid upload'});try{const analyzed=await analyzeImage(null,fields||{});res.json(analyzed)}catch(e){console.error(e);res.status(500).json({error:'Failed to analyze image'})}})});export default router
