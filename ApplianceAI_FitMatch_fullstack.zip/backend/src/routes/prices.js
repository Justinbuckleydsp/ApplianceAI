import express from 'express'
import {fetchRetailerQuotes} from '../services/retailers/index.js'
import {rankWithAI} from '../services/ai_client.js'
const router=express.Router()
router.get('/',async(req,res)=>{try{const {type='Dishwasher',width_in='24',height_in='34',depth_in='24',query=''}=req.query;const quotes=await fetchRetailerQuotes({type,width_in:Number(width_in),height_in:Number(height_in),depth_in:Number(depth_in),query});const withTotals=quotes.map(x=>({...x,total_price:Number(x.price||0)+Number(x.delivery_fee||0)+Number(x.tax||0)}));const items=await rankWithAI(withTotals);const summary={cheapest_total:items.length?items[0].total_price:0,cheapest_store:items.length?items[0].store:null};res.json({items,summary})}catch(e){console.error(e);res.status(500).json({error:'Failed to fetch prices'})}});export default router
