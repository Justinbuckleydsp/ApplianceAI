
# ApplianceAI — Photo-to-Fit + Price Match (Full-Stack Starter)
[See README details in prior step; full instructions included.]
