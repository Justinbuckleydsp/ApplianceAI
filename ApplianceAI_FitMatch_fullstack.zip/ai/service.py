from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional, List
app=FastAPI(title='ApplianceAI Service')
class AnalyzeRequest(BaseModel):
    assumed_type: Optional[str]=None
class AnalyzeResponse(BaseModel):
    type:str;width_in:float;height_in:float;depth_in:float;confidence:float
    notes:Optional[str]=None
class Quote(BaseModel):
    store:str;name:str;price:float;delivery_fee:float;tax:float;delivery_eta:str
class RankRequest(BaseModel):
    quotes:List[Quote]
STANDARD={'Dishwasher':(24.0,34.0,24.0),'Refrigerator':(36.0,70.0,30.0),'Range':(30.0,36.0,27.0),'Microwave':(30.0,17.0,16.0),'Washer':(27.0,39.0,31.0),'Dryer':(27.0,39.0,31.0)}
def penalty(eta:str)->float:
    if eta and 'Next-Day' in eta:return 0.0
    if eta and ('2–3 Days' in eta or '2-3 Days' in eta):return 10.0
    return 20.0
@app.get('/')
def root():return {'ok':True,'service':'ApplianceAI Service'}
@app.post('/analyze',response_model=AnalyzeResponse)
def analyze(req:AnalyzeRequest):
    t=req.assumed_type or 'Dishwasher'
    w,h,d=STANDARD.get(t,STANDARD['Dishwasher'])
    return AnalyzeResponse(type=t,width_in=w,height_in=h,depth_in=d,confidence=0.82,notes='Stubbed vision. Replace with real model.')
@app.post('/rank')
def rank(req:RankRequest):
    items=[]
    for q in req.quotes:
        tot=(q.price or 0)+(q.delivery_fee or 0)+(q.tax or 0)
        s=tot+penalty(q.delivery_eta)
        items.append({'store':q.store,'name':q.name,'price':q.price,'delivery_fee':q.delivery_fee,'tax':q.tax,'delivery_eta':q.delivery_eta,'total_price':round(tot,2),'score':round(s,2)})
    items.sort(key=lambda x:(x['score'],x['total_price']))
    return {'items':items}
